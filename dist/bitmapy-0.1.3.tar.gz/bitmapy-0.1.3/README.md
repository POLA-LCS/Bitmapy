# Bitmapy

A work in progress bitmap manager with python.